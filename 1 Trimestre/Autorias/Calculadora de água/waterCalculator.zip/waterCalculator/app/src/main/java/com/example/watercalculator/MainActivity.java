package com.example.watercalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

  EditText nameInput, weightInput;
  Button calc;
  TextView result;

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_main);
    getSupportActionBar().hide();
    nameInput = findViewById(R.id.nameInput);
    weightInput = findViewById(R.id.weightInput);
    calc = findViewById(R.id.button);
    result = findViewById(R.id.result);
    calc.setOnClickListener(click -> {
      if (!weightInput.getText().toString().equals("") && !nameInput.getText().toString().equals("")) {
        calcular(nameInput.getText().toString(), Integer.parseInt(weightInput.getText().toString()));
      }
    });
  }

  public void calcular(String name, int peso) {
    float totalAgua = peso * 35;
    result.setText(name + " você precisa tomar aproximadamente no minimo " + (totalAgua / 1000) + " litros de água por dia");
  }
}