package com.example.calchour;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

  EditText horas1Input, horas2Input, minutos1Input, minutos2Input;
  Button btnSub, btnSom;
  TextView result;

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_main);
    getSupportActionBar().hide();

    horas1Input = findViewById(R.id.horas1Input);
    horas2Input = findViewById(R.id.horas2Input);
    minutos1Input = findViewById(R.id.minutos1Input);
    minutos2Input = findViewById(R.id.minutos2Input);
    btnSub = findViewById(R.id.btnSub);
    btnSom = findViewById(R.id.btnSom);
    result = findViewById(R.id.result);

    btnSom.setOnClickListener(new View.OnClickListener() {
      @Override
      public void onClick(View view) {
        somar();
      }
    });

    btnSub.setOnClickListener(new View.OnClickListener() {
      @Override
      public void onClick(View view) {
        subtrair();
      }
    });
  }

  public boolean somar() {
    try {
      String horas1 = horas1Input.getText().toString();
      String minutos1 = minutos1Input.getText().toString();
      String horas2 = horas2Input.getText().toString();
      String minutos2 = minutos2Input.getText().toString();
      if (horas1.equals("") || minutos1.equals("") || horas2.equals("") || minutos2.equals("")) {
        Toast.makeText(this, "Insira um valor em todos os campos númericos antes de continuar", Toast.LENGTH_SHORT).show();
        return false;
      } else if (Integer.parseInt(horas1) < 0 || Integer.parseInt(horas2) < 0 || Integer.parseInt(minutos1) < 0 || Integer.parseInt(minutos2) < 0) {
        Toast.makeText(this, "Insira um valor positivo em todos os campos númericos antes de continuar", Toast.LENGTH_SHORT).show();
        return false;
      }
      int resultadoHora = Integer.parseInt(horas1) + Integer.parseInt(horas2);
      int resultadoMin = Integer.parseInt(minutos1) + Integer.parseInt(minutos2);
      while (resultadoMin >= 60) {
        resultadoMin = resultadoMin - 60;
        resultadoHora = resultadoHora + 1;
      }
      result.setVisibility(View.VISIBLE);
      String resultText = resultadoHora + " horas e " + resultadoMin + " minutos";
      result.setText(resultText);
      return true;
    } catch (Exception e) {
      Toast.makeText(this, "Ocorreu algum erro durante a execução do cálculo, tente novamente", Toast.LENGTH_SHORT).show();
      System.out.println(e);
      return false;
    }
  }

  public boolean subtrair() {
    try {
      String horas1 = horas1Input.getText().toString();
      String minutos1 = minutos1Input.getText().toString();
      String horas2 = horas2Input.getText().toString();
      String minutos2 = minutos2Input.getText().toString();
      if (horas1.equals("") || minutos1.equals("") || horas2.equals("") || minutos2.equals("")) {
        Toast.makeText(this, "Insira um valor em todos os campos númericos antes de continuar", Toast.LENGTH_SHORT).show();
        return false;
      } else if (Integer.parseInt(horas1) < 0 || Integer.parseInt(horas2) < 0 || Integer.parseInt(minutos1) < 0 || Integer.parseInt(minutos2) < 0) {
        Toast.makeText(this, "Insira um valor positivo em todos os campos númericos antes de continuar", Toast.LENGTH_SHORT).show();
        return false;
      }
      int horas1_val = Integer.parseInt(horas1);
      int horas2_val = Integer.parseInt(horas2);
      int minutos1_val = Integer.parseInt(minutos1);
      int minutos2_val = Integer.parseInt(minutos2);
      int resultadoHora = 0, resultadoMin = 0;
      int linha1 = 0;
      int linha2 = 0;
      int resultadoTotal = 0;
      while (horas1_val > 0) {
        linha1 += 60;
        horas1_val -= 1;
      }
      while (horas2_val > 0) {
        linha2 += 60;
        horas2_val -= 1;
      }
      if (minutos1_val >= 60) {
        while (minutos1_val >= 60) {
          linha1 += 60;
          minutos1_val -= 60;
        }
        linha1 += minutos1_val;
      } else {
        linha1 += minutos1_val;
      }
      if (minutos2_val >= 60) {
        while (minutos2_val >= 60) {
          linha2 += 60;
          minutos2_val -= 60;
        }
        linha2 += minutos2_val;
      } else {
        linha2 += minutos2_val;
      }
      if (linha1 < linha2) {
        resultadoTotal = linha2 - linha1;
      } else {
        resultadoTotal = linha1 - linha2;
      }
      while (resultadoTotal >= 60) {
        resultadoHora++;
        resultadoTotal -= 60;
      }
      resultadoMin = resultadoTotal;
      result.setVisibility(View.VISIBLE);
      String resultText = resultadoHora + " horas e " + resultadoMin + " minutos";
      result.setText(resultText);
      return true;
    } catch (Exception e) {
      Toast.makeText(this, "Ocorreu algum erro durante a execução do cálculo, tente novamente", Toast.LENGTH_SHORT).show();
      System.out.println(e);
      return false;
    }
  }
}